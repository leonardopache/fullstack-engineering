def call(boolean quality_gate = true, boolean abort_pipeline = true){
	if(quality_gate){
		echo "Los tested del Quality gate han pasado con exito!!"
	} else if(!abort_pipeline){
		echo "Los testes no han pasado pero no aborta el pipeline"
	} else {
		echo "Los testes no han pasado pipeline abortado"
	}
}
