def call(boolean quality_gate = true, boolean abort_pipeline = true, String branch){
	if(quality_gate){
		echo "Los tested del Quality gate han pasado con exito!!"
	} else {
		if ((branch == "master" || branch.startsWith(hotfix)) && abort_pipeline){
			echo "Los testes no han pasado, como es la rama master o hotfix, pipeline abortado"
		} else {
			echo "Los testes no han pasado pero no aborta el pipeline"
		}
	}
}
