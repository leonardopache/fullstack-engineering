# Getting Started with Create React App

### `npm start`

Runs the app in the development mode.\
Open [http://localhost:3000/react-week4](http://localhost:3000/react-week4) to view it in the browser.


### Github Page

This activity is deployed in [https://leonardopache.github.io/react-week4/](https://leonardopache.github.io/react-week4/) but for any reason can't find the internal pages.


