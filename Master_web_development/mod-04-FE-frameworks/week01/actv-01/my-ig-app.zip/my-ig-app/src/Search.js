function Search() {
    return (
        <input className="form-control" list="datalistOptions" id="exampleDataList" 
                placeholder="Type to search..."></input>
    )
}

export default Search;